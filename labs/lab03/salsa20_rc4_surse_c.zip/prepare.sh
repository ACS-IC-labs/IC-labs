#!/bin/bash

dd if=/dev/urandom of=file.bin bs=1M count=200
dd if=/dev/urandom of=key.bin bs=1 count=256
dd if=/dev/urandom of=nonce.bin bs=1 count=8
gcc -O3 main.c -o main
