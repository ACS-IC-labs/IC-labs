#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include <string.h>

#include "salsa20.h"
#include "rc4.h"

void print_usage();
int readall(char *file_name, char **buff_ptr, size_t *size_ptr);
int writeall(char *file_name, char *buff, size_t size);

int main(int argc, char **argv)
{
    char *output_file = NULL;
    char *output_buff = NULL;
    size_t output_size = 0;
    char *input_file = NULL;
    char *input_buff = NULL;
    size_t input_size = 0;
    char *nonce_file = NULL;
    char *nonce_buff = NULL;
    size_t nonce_size = 0;
    char *key_file = NULL;
    char *key_buff = NULL;
    double time_taken = 0;
    size_t key_size = 0;
    int exit_code = -1;
    int salsa_flag = 0;
    int rc4_flag = 0;
    int success = 0;
    opterr = 0;
    clock_t t;
    int c;

    while ((c = getopt(argc, argv, "hsri:o:k:n:")) != -1)
    switch (c)
    {
        case 'h':
            print_usage();
            goto exit;
        break;
        case 's':
            salsa_flag = 1;
        break;
        case 'r':
            rc4_flag = 1;
        break;
        case 'i':
            input_file = optarg;
        break;
        case 'o':
            output_file = optarg;
        break;
        case 'k':
            key_file = optarg;
        break;
        case 'n':
            nonce_file = optarg;
        break;
        case '?':
            if (optopt == 'i' || optopt == 'o' || optopt == 'k' || optopt == 'n')
                fprintf(stderr, "Option -%c requires an argument.\n", optopt);
            else if (isprint(optopt))
                fprintf(stderr, "Unknown option `-%c'.\n", optopt);
            else
                fprintf(stderr, "Unknown option character `\\x%x'.\n", optopt);
            goto exit;
        default:
            goto exit;
    }

    if (!salsa_flag && !rc4_flag) {
        perror("No cipher alg selected");
        goto exit;
    }

    if (salsa_flag && rc4_flag) {
        perror("Can't use both ciphers at once");
        goto exit;
    }

    if (rc4_flag && nonce_file) {
        printf("Warning. Rc4 do not require nonce file. Continuing...\n");
    }

    if (readall(input_file, &input_buff, &input_size)) {
        perror("Failed to read input file");
        goto exit;
    }

    if (readall(key_file, &key_buff, &key_size)) {
        perror("Failed to read output file");
        goto exit;
    }

    if (!(key_size == 128 || key_size == 256)) {
        printf("Key size is %zu\n", key_size);
        perror("Key size must be 128 or 256");
        goto exit;
    }

    if (nonce_file) {
        if (readall(nonce_file, &nonce_buff, &nonce_size)) {
            perror("Failed to read nonce file");
            goto exit;
        }
    }

    output_size = input_size;
    output_buff = (char *)malloc(output_size);
    if (!output_file)
        goto exit;
    memcpy((void *)output_buff, (void *)input_buff, output_size);

    t = clock();
    {
        if (salsa_flag) {
             enum s20_status_t ret = s20_crypt((uint8_t *)key_buff, key_size == 128 ? S20_KEYLEN_128 : S20_KEYLEN_256,
                                               (uint8_t *)nonce_buff, 0, (uint8_t *)output_buff, (uint32_t)output_size);
             success = ret == S20_SUCCESS;
        }
        else if (rc4_flag) {
            RC4((unsigned char *)input_buff, (long)input_size, (unsigned char *)key_buff, (long)key_size, (unsigned char *)output_buff);
            success = 1;
        }
    }
    t = clock() - t;
    time_taken = ((double)t)/CLOCKS_PER_SEC;
    printf("Operation ended with %s. Duration: %f seconds\n", success ? "SUCCESS" : "FAILURE", time_taken);

    if (success && output_file)
        writeall(output_file, output_buff, output_size);

    exit_code = 0;
exit:
    if (input_buff)
        free(input_buff);
    if (output_buff)
        free(output_buff);
    if (key_buff)
        free(key_buff);
    if (nonce_buff)
        free(nonce_buff);

    return exit_code;
}


void print_usage()
{
    printf("Options:\n"
           "-h      help\n"
           "-s      specifies that salsa20 will be used\n"
           "-r      specifies that rc4 will be used\n"
           "-i      specifies input file\n"
           "-o      specifies output file\n"
           "-k      specifies key file\n"
           "-n      specifies nonce file\n");
}

int writeall(char *file_name, char *buff, size_t size)
{
    if (!file_name || !buff || !size)
        return -1;

    FILE *f_dst = fopen(file_name, "wb");
    if(!f_dst){
        perror("Fopen");
        return -1;
    }

    if(fwrite(buff, 1, size, f_dst) != size) {
        perror("Fwrite");
        return -1;
    }

    fclose(f_dst);
    return -1;
}

int readall(char *file_name, char **buff_ptr, size_t *size_ptr)
{
    if (!file_name || !buff_ptr || !size_ptr) {
        perror("Null args");
        return -1;
    }

    FILE *fh = fopen(file_name, "rb");
    if (fh == NULL) {
        perror("Fopen");
        return -1;
    }

    fseek(fh, 0L, SEEK_END);
    long s = ftell(fh);
    rewind(fh);
    *buff_ptr = (char *)malloc(s);
    if (*buff_ptr == NULL) {
        perror("Malloc");
        fclose(fh);
        return -1;
    }

    *size_ptr = (size_t)s;
    fread(*buff_ptr, s, 1, fh);
    fclose(fh);
    return 0;
}
