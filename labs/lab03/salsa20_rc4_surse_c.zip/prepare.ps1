$out = new-object byte[] (204800*1024);
(new-object Random).NextBytes($out);
[IO.File]::WriteAllBytes('file.bin', $out)
$out = new-object byte[] 256;
(new-object Random).NextBytes($out);
[IO.File]::WriteAllBytes('key.bin', $out)
$out = new-object byte[] 8;
(new-object Random).NextBytes($out);
[IO.File]::WriteAllBytes('nonce.bin', $out)
